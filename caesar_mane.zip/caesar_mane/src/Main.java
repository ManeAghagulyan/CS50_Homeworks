import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String text, code_text="";
        int j;
        text="This is CS50";
        int key=scan.nextInt()%26;
        int len=text.length();
        for(j=0; j<len; j++)
        {
            char c=text.charAt(j);
            if(Character.isLetter(c)){
                if(Character.isLowerCase(c)) {

                    c = (char) ((((int) c - 97 + key) % 26) + 97);
                }
                else {
                    c = (char) ((((int) c-65 + key)%26)+65);
                }
            }

            code_text+=Character.toString(c);

        }
        System.out.println(code_text);
    }
}
