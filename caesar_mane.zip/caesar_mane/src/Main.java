import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String text, code_text="";
        int j;
        text="This is CS50";
        int key=scan.nextInt()%26;
        int len=text.length();
        for(j=0; j<len; j++)
        {
            char c=text.charAt(j);
            if(Character.isLetter(c)){
                if(Character.isLowerCase(c)) {
                    if ((int) c + key > 122)
                        c = (char) ((int) c + key - 26);
                    else
                        c = (char) ((int) c + key);
                }
                if(Character.isUpperCase(c)) {
                    if ((int) c + key > 90)
                        c = (char) ((int) c + key - 26);
                    else
                        c = (char) ((int) c + key);
                }
            }

            code_text+=Character.toString(c);

        }
        System.out.println(code_text);
        System.out.println(len);
    }
}
