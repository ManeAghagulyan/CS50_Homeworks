// coins 50cent, 25, 10, 5, 1
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        int coin=0, q=0;
        do
        {
            coin= scan.nextInt();
        } while (coin<=0);

        if (coin>=50)
        {
            q+=coin/50;
            coin=coin%50;
        }

        if (coin>=25)
        {
            q+=coin/25;
            coin=coin%25;
        }
        if (coin>=10)
        {
            q+=coin/10;
            coin=coin%10;
        }
        if (coin>=5)
        {
            q+=coin/5;
            coin=coin%5;
        }
        else
        {q+=coin;}

        System.out.println("pahanjvum e "+q+" coin");
    }
}
