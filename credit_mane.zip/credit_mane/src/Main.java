//credit card validation
import java.util.Scanner;
public class Main {

    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        int  i=0;
        long number,sum=0,num;
        do
            {
            number=scan.nextLong();
        } while(number<1000000000);

        while(number>0)
        {
            num=number%10;
            number/=10;
            i++;
            if(i%2==0)
            {
                if (num*2>9)
                    sum=sum+(num*2)/10+(num*2)%10;
                else
                    sum=sum+(num*2);
            }
            else
                {
                    sum+=num;
                }
        }
        if(sum%10==0 && sum!=0)
            System.out.println("Your card is valid");
        else
            System.out.println("Your card is not valid");
        System.out.println(" sum="+sum);
    }
}
