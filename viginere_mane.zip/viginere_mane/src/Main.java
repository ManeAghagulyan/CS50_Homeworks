import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String text, code_text="", key;
        int j;
        System.out.println("Enter a base string");
        text=scan.nextLine();
        System.out.println("Enter a key string");
        key=scan.nextLine();
        int len=text.length();
        int len_key=key.length();
        int jj=0;
        for(j=0; j<len; j++)
        {
            char c=text.charAt(j);
            if(Character.isLetter(c)){
                char c_key=key.charAt(jj%len_key);

                int j_key=((int)c_key>96)?(int)c_key-97 :(int)c_key-65 ;

                if(Character.isLowerCase(c)) {

                    c = (char) ((((int) c - 97 + j_key) % 26) + 97);
                }
                else {
                    c = (char) ((((int) c-65 + j_key)%26)+65);
                }
                jj++;
            }
            code_text+=Character.toString(c);

        }
        System.out.println("Encrypted text is \n"+code_text);

    }
}
